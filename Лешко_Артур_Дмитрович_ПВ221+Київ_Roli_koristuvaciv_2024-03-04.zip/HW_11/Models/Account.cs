﻿using Microsoft.AspNetCore.Identity;

namespace HW_11.Models;

public class Account : IdentityUser<int>
{

}
