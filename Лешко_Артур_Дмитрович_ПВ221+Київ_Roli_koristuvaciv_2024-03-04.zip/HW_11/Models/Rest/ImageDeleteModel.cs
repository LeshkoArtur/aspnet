﻿namespace HW_11.Models.Rest;

public class ImageDeleteModel
{
    public string Src { get; set; } = null!;
    public int Id { get; set; }
}
