﻿namespace HW_11.Models.Rest;

public class PositionDeleteModel
{
	public int id { get; set; }
}
