﻿namespace HW_11.Models.Rest;

public class UserDeleteModel
{
	public int id { get; set; }
}
