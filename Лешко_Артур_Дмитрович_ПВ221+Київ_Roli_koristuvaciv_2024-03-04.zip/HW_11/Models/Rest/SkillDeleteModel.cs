﻿namespace HW_11.Models.Rest;

public class SkillDeleteModel
{
	public int id { get; set; }
}
