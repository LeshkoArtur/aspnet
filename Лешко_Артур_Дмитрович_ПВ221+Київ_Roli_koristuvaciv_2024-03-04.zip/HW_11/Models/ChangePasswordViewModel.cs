﻿using System.ComponentModel.DataAnnotations;

namespace HW_11.Models
{
	public class ChangePasswordViewModel
	{
		[Required]
		[DataType(DataType.Password)]
		[Display(Name = "Старий пароль")]
		public string OldPassword { get; set; }

		[Required]
		[StringLength(100, ErrorMessage = "Пароль повинен містити не менше {2} символів.", MinimumLength = 6)]
		[DataType(DataType.Password)]
		[Display(Name = "Новий пароль")]
		public string NewPassword { get; set; }

		[DataType(DataType.Password)]
		[Display(Name = "Підтвердження нового паролю")]
		[Compare("NewPassword", ErrorMessage = "Новий пароль та підтвердження паролю не співпадають.")]
		public string ConfirmPassword { get; set; }
	}

}
