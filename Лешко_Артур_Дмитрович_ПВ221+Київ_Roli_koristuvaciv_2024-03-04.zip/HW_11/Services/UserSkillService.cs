﻿using HW_11.Interfaces;
using HW_11.Models;
using HW_11.Models.Form;
using Microsoft.EntityFrameworkCore;

namespace HW_11.Services;

public class UserSkillService
{
	private readonly IUserSkillRepository _userSkillRepository;
	private readonly ISkillRepository _skillRepository;

	public UserSkillService(IUserSkillRepository userSkillRepository, ISkillRepository skillRepository)
	{
		_userSkillRepository = userSkillRepository;
		_skillRepository = skillRepository;
	}

	public async Task<bool> CreateUserSkill(UserSkillForm form, int id)
	{
		var userSkill = new UserSkill();
		userSkill.ProficiencyLevel = form.ProficiencyLevel;
		userSkill.SkillId = form.SkillId;
		userSkill.UserId = id;

		await _userSkillRepository.AddAsync(userSkill);
		await _userSkillRepository.SaveAsync();

		return true;
	}

	public async Task<List<Skill>> GetSkills()
	{
		var list = await _skillRepository.GetAllAsync();
		return await list.ToListAsync();
	}
}
