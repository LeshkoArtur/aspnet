﻿using HW_11.Models.Form;
using HW_11.Services;
using Microsoft.AspNetCore.Mvc;

namespace HW_11.Controllers
{
	public class UserSkillController : Controller
	{
		private readonly UserSkillService _userSkillService;

		public UserSkillController(UserSkillService skillService)
		{
			_userSkillService = skillService;
		}

		[HttpGet]
		public async Task<IActionResult> CreateUserSkill(int id)
		{
			ViewData["UserId"] = id;
			ViewData["Skills"] = await _userSkillService.GetSkills();

			return View(new UserSkillForm());
		}

		[HttpPost]
		[AutoValidateAntiforgeryToken]
		public async Task<IActionResult> CreateUserSkill(int id, [FromForm] UserSkillForm form)
		{
			if (!ModelState.IsValid)
			{
				ViewData["UserId"] = id;
				ViewData["Skills"] = await _userSkillService.GetSkills();
				return View(form);
			}
			var exists = await _userSkillService.CreateUserSkill(form, id);

			if (!exists)
			{
				ViewData["UserId"] = id;
				ViewData["Skills"] = await _userSkillService.GetSkills();
				return View(form);
			}

			return RedirectToAction("Edit", new { controller = "Home", id });
		}
	}
}
