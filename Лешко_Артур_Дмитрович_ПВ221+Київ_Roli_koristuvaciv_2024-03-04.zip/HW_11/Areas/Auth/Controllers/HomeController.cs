﻿using HW_11.Areas.Auth.Models.Form;
using HW_11.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Security.Claims;

namespace HW_11.Areas.Auth.Controllers;

[Area("Auth")]
public class HomeController : Controller
{
	private readonly UserManager<Account> _userManager;

	public HomeController(UserManager<Account> userManager)
	{
		_userManager = userManager;
	}

	[HttpGet]
	public async Task<IActionResult> Login(string? returnUrl)
	{
		return View(new LoginForm());
	}

	[HttpPost]
	public async Task<IActionResult> Login([FromForm] LoginForm form, string? returnUrl)
	{
		if (!ModelState.IsValid)
		{
			return View(form);
		}

		// Перевірка на те що такий користувач вже існує
		var user = await _userManager.FindByEmailAsync(form.Login);
		if (user == null)
		{
			ModelState.AddModelError(nameof(form.Login), "Користувач з таким логіном не існує");
			return View(form);
		}

		// Перевірка пароля

		if (!await _userManager.CheckPasswordAsync(user, form.Password))
		{
			ModelState.AddModelError(nameof(form.Login), "Пароль не дійсний");
			return View(form);
		}

		// !!! Користувач успішно створено!
		var identity = new ClaimsIdentity(IdentityConstants.ApplicationScheme);
		identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()));
		identity.AddClaim(new Claim(ClaimTypes.Name, user!.UserName!));
		identity.AddClaim(new Claim(ClaimTypes.Email, user!.Email!));
		//TODO roles

		await HttpContext
			.SignInAsync(IdentityConstants.ApplicationScheme, new ClaimsPrincipal(identity));


		if (returnUrl != null)
		{
			return Redirect(returnUrl);
		}

		return RedirectToAction("Index", "Home", new { area = "" });
	}

	[HttpGet]
	public async Task<IActionResult> Register(string? returnUrl)
	{
		return View(new RegisterForm());
	}

	[HttpPost]
	public async Task<IActionResult> Register([FromForm] RegisterForm form, string? returnUrl)
	{
		if (!ModelState.IsValid)
		{
			return View(form);
		}

		if (form.Password != form.ConfirmPassword)
		{
			ModelState.AddModelError(nameof(form.ConfirmPassword), "Паролі повинні співпадати");
			return View(form);
		}

		// Перевірка на те що такий користувач вже існує
		var user = await _userManager.FindByEmailAsync(form.Login);
		if (user != null)
		{
			ModelState.AddModelError(nameof(form.Login), "Користувач з таким логіном вже існує");
			return View(form);
		}

		// Створення користувача
		user = new Account
		{
			Email = form.Login,
			UserName = form.Login,
			EmailConfirmed = true,
		};

		var result = await _userManager.CreateAsync(user, form.Password);

		if (!result.Succeeded)
		{
			ModelState.AddModelError(nameof(form.Login),
				string.Join(";", result.Errors.ToList()!.Select(x => x.Description))
				);
			return View(form);
		}

		// !!! Користувач успішно створено!
		var identity = new ClaimsIdentity(IdentityConstants.ApplicationScheme);
		identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()));
		identity.AddClaim(new Claim(ClaimTypes.Name, user.UserName));
		identity.AddClaim(new Claim(ClaimTypes.Email, user.Email));
		//TODO roles

		await HttpContext
			.SignInAsync(IdentityConstants.ApplicationScheme, new ClaimsPrincipal(identity));

		if (returnUrl != null)
		{
			return Redirect(returnUrl);
		}

		return RedirectToAction("Index", "Home", new { area = "" });
	}


	[HttpGet]
	[Authorize]
	public async Task<IActionResult> Logout(string? returnUrl)
	{
		await HttpContext.SignOutAsync(IdentityConstants.ApplicationScheme);

		return RedirectToAction("Index", "Home", new { area = "" });
	}

	[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
	public IActionResult Error()
	{
		return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
	}
}