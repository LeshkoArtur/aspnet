﻿using System.ComponentModel.DataAnnotations;

namespace HW_11.Areas.Auth.Models.Form;

public class RegisterForm
{
    [Display(Name = "Пошта")]
    [Required(ErrorMessage = "обов`зково")]
    public string Login { get; set; } = null!;

    [Display(Name = "Пароль")]
    [Required(ErrorMessage = "обов`зково")]
    public string Password { get; set; } = null!;

    [Display(Name = "Підтвердити пароль")]
    [Required(ErrorMessage = "обов`зково")]
    public string ConfirmPassword { get; set; } = null!;
}